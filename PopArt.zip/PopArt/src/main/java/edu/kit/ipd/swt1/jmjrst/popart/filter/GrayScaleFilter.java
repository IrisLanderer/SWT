package edu.kit.ipd.swt1.jmjrst.popart.filter;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class GrayScaleFilter implements ImageFilter {

	@Override
	public BufferedImage applyFilter(BufferedImage image) {
		for (int i = 0; i < image.getWidth(); i++) {
			for (int j = 0; j < image.getHeight(); j++) {
				int grey = image.getRGB(i, j) / 3;
				int red = grey;
				int yellow = grey;
				int blue = grey;
				Color newColor = new Color(red, yellow, blue);
				image.setRGB(i, j, newColor.getRGB());
			}
		}
		return image;
	}

}
