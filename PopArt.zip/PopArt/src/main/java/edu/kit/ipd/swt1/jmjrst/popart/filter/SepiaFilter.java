package edu.kit.ipd.swt1.jmjrst.popart.filter;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class SepiaFilter implements ImageFilter {

	private int sepiaDepth;
	private int sepiaIntensity;

	public SepiaFilter() {
		this(20, 10);
	}

	public SepiaFilter(int depth, int intensity) {
		sepiaDepth = depth;
		sepiaIntensity = intensity;
	}

	@Override
	public BufferedImage applyFilter(BufferedImage image) {
		if (sepiaDepth < 0) {
			sepiaDepth = 0;
		}
		if (sepiaDepth > 255) {
			sepiaDepth = 255;
		}
		if (sepiaIntensity < 0) {
			sepiaIntensity = 0;
		}
		if (sepiaIntensity > 255) {
			sepiaIntensity = 255;
		}

		for (int i = 0; i < image.getWidth(); i++) {
			for (int j = 0; j < image.getHeight(); j++) {
				int grey = image.getRGB(i, j) / 3;
				int red = grey;
				int yellow = grey + 2 * sepiaDepth;
				int blue = sepiaDepth - sepiaIntensity;
				Color newColor = new Color(red, yellow, blue);
				image.setRGB(i, j, newColor.getRGB());
			}
		}
		return image;
	}
}
