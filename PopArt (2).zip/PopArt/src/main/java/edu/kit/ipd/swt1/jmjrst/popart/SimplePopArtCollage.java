package edu.kit.ipd.swt1.jmjrst.popart;
import java.awt.image.BufferedImage;

public class SimplePopArtCollage {

	public BufferedImage getCollage(BufferedImage image, String optionValue) {
		return image;
	}
}
