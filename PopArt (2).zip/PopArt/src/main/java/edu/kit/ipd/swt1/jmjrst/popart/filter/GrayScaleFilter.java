package edu.kit.ipd.swt1.jmjrst.popart.filter;

import java.awt.Color;
import java.awt.image.BufferedImage;

/**
 * Klasse für einen Graustufenfilter
 * 
 * @author Iris
 *
 */
public class GrayScaleFilter implements ImageFilter {

	@Override
	public BufferedImage applyFilter(BufferedImage image) {
		for (int i = 0; i < image.getWidth(); i++) {
			for (int j = 0; j < image.getHeight(); j++) {
				// Durchschnitt der drei Farben wird berechnet
				int grey = image.getRGB(i, j) / 3;
				Color newColor = new Color(grey, grey, grey);
				image.setRGB(i, j, newColor.getRGB());
			}
		}
		return image;
	}

}
