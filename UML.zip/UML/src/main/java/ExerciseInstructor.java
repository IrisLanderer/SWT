public class ExerciseInstructor {
	private String name;

	public ExerciseInstructor(String name) {
		this.name = name;
	}

	public boolean test(Student student) {
		return true;
	}

	public boolean test(PartyStudent student) {
		if (student.getIsClever() == true) {
			return true;
		}
		return false;
	}

	public String getName() {
		return this.name;
	}
}
