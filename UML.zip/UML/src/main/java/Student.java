public class Student {
	private String name;

	public Student(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public void hasExerciseLicence(ExerciseInstructor instructor) {
		if (instructor.test(this) == true) {
			System.out.println("Der Student " + this.getName()
					+ " hat den �bungsschein erhalten :)");
		} else {
			System.out.println("Der Student " + this.getName()
					+ " hat den �bungsschein nicht erhalten :(");
		}
	}
}
