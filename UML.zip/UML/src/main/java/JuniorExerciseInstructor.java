public class JuniorExerciseInstructor extends ExerciseInstructor {

	public JuniorExerciseInstructor(String name) {
		super(name);
	}

	@Override
	public boolean test(PartyStudent student) {
		student.learn();
		return true;
	}
}
