public class PartyStudent extends Student {

	private boolean isClever;

	public PartyStudent(String name) {
		super(name);
		this.isClever = false;
	}

	public void learn() {
		isClever = true;
	}

	public boolean getIsClever() {
		return this.isClever;
	}
}
