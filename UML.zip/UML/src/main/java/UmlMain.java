public class UmlMain {

	public static void main(String[] args) {
		Student student = new Student("Iris");
		PartyStudent partystudent = new PartyStudent("Max");
		ExerciseInstructor instructor = new ExerciseInstructor("Blersch");
		JuniorExerciseInstructor junior = new JuniorExerciseInstructor(
				"Landh�u�er");
		student.hasExerciseLicence(instructor);
		student.hasExerciseLicence(junior);
		partystudent.hasExerciseLicence(instructor);
		partystudent.hasExerciseLicence(junior);
	}

}
